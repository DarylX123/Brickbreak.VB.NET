﻿Public Class Form1

    Private X As Integer = 4
    Private y As Integer = -3
    Private intpuntos As Integer = 0
    Private intvidas As Integer = 3

    Const MaximoDeLadrillos As Integer = 20
    Private Romper(MaximoDeLadrillos + 1) As PictureBox

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Romper(0) = PictureBox1
        Romper(1) = PictureBox2
        Romper(2) = PictureBox3
        Romper(3) = PictureBox4
        Romper(4) = PictureBox5
        Romper(5) = PictureBox6
        Romper(6) = PictureBox7
        Romper(7) = PictureBox8
        Romper(8) = PictureBox9
        Romper(9) = PictureBox10
        Romper(10) = PictureBox11
        Romper(11) = PictureBox12
        Romper(12) = PictureBox13
        Romper(13) = PictureBox14
        Romper(14) = PictureBox15
        Romper(15) = PictureBox16
        Romper(16) = PictureBox17
        Romper(17) = PictureBox18
        Romper(18) = PictureBox19
        Romper(19) = PictureBox20
        Romper(20) = PictureBox21
        Romper(20) = PictureBox21
        Romper(20) = PictureBox21



    End Sub

    Private Sub DesplazarPelota()
        Pelota.Left += X
        Pelota.Top += y

        If Pelota.Top < 0 Then
            y = -y
        End If

        If Pelota.Left < 0 Then
            X = -X
        End If
        If Pelota.Right > Me.Width - 20 Then
            X = -X
        End If
        If Pelota.Bottom > Me.Height - 30 Then
            intvidas -= 1
            vidas2.Text = intvidas
            Pelota.Top = Me.Height / 2
            If intvidas = 0 Then
                Timer1.Enabled = False
                MsgBox("Fin del Juego")
            End If
        End If

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        Call DesplazarPelota()
        Call ChocarConPelota()
        Call ChocarConLadrillos()
        Call FinDelNivel()
    End Sub

    Private Sub ChocarConLadrillos()
        Dim I As Integer
        For I = 0 To MaximoDeLadrillos

            If Pelota.Bounds.IntersectsWith(Romper(I).Bounds) Then

                If Romper(I).Visible = True Then
                    Romper(I).Visible = False

                    y = -y

                    intpuntos += 1
                    puntos2.Text = intpuntos
                End If
            End If
        Next
    End Sub

    Private Sub ChocarConPelota()

        If Pelota.Bounds.IntersectsWith(Barra.Bounds) Then
            y = -y

            Dim golpeCentral As Integer = Barra.Left + Barra.Width / -100
            Dim pelotaCentral As Integer = Barra.Right + Barra.Width / +100
            Dim intDiff As Integer = pelotaCentral - golpeCentral
            X = intDiff / 20

        End If
    End Sub

    Private Sub FinDelNivel()

        Dim i As Integer

        For i = 0 To MaximoDeLadrillos
            If Romper(i).Visible = True Then
                Exit Sub
            End If
        Next

        For i = 0 To MaximoDeLadrillos
            Romper(i).Visible = True
        Next

    End Sub
    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        Barra.Left = e.X

    End Sub
End Class


